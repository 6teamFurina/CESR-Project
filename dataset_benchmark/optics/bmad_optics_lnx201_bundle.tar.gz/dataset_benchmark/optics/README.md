# CESR chromatic-optics benchmark

This directory contains one unified RF-off/coasting optics benchmark for the
same CESR corrector samples and the same 99 zero-length `DET_*` markers.

Both engines output the zero-order periodic optics and their first derivatives
with respect to relative momentum deviation `delta`:

- `phi_1`, `beta_1`, `alpha_1`, `phi_2`, `beta_2`, `alpha_2`;
- longitudinal accumulated phase `phi_3`;
- coupled-optics `gamma_c`, `c11`, `c12`, `c21`, `c22`;
- the six propagated orbit coordinates;
- one `d..._ddelta` column for every quantity above;
- ring tunes, transverse chromaticities, and the coasting slip coefficient.

The orbit derivatives provide the dispersion response. These are phase-space
derivatives with respect to `delta`, not derivatives with respect to the 119
corrector controls.

## SciBmad

Run locally from the CESR project root:

```powershell
$env:JULIA_PKG_PRECOMPILE_AUTO='0'
julia --project=. dataset_benchmark/optics/benchmark_scibmad_chromatic_optics.jl
```

SciBmad constructs the CESR scalar model, detector list, and
`Descriptor(6, 2)` exactly once. The existing response-linear/frozen-Jacobian
RF-on batch orbit supplies initial guesses for a short RF-off four-dimensional
coasting-orbit solve. The coasting orbit is passed explicitly to `twiss`, so
`twiss` does not solve it again.

The default 10-sample local result is:

| Quantity | Result |
|---|---:|
| Twiss physics time | 5.848 s |
| Throughput | 1.710 samples/s |
| Mean sample time | 0.572 s |
| Timed allocation | 3.071 GB |
| Additional 10-sample coasting-orbit solve | 0.488 s |
| Maximum transverse closure residual | `4.55e-13` |

Warmup/compilation, closed-orbit work, setup, and CSV writing are excluded from
`twiss_physics_seconds` and recorded separately in metadata.

SciBmad writes under `results/chromatic_test_10`:

- `scibmad_detector_chromatic_twiss.csv`: 990 rows, 40 columns;
- `scibmad_ring_chromatic_twiss.csv`: 10 ring rows;
- `scibmad_start_closed_orbits.csv`;
- `scibmad_chromatic_optics_metadata.toml`;
- `local_run_rf_off.log`.

## Bmad/Tao

The Bmad benchmark uses one persistent Tao instance with RF off. For each
corrector sample it computes periodic optics at `pz=0`, `pz=+h`, and `pz=-h`.
Bmad's native dispersion fields are used when the installed Tao exposes them.
The beta/alpha chromatic derivatives use the same symmetric `pz=+h/-h`
difference as the remaining local phase and coupling derivatives. This is
deliberate: Tao 20260726-0 accepts the undocumented
`ele.a/b.dbeta_dpz` and `ele.a/b.dalpha_dpz` `lat_list` selectors but silently
returns the same mode array for both requests. The already-computed symmetric states
avoid that ambiguous interface without adding lattice calculations.
`ring_general.chrom_a/chrom_b` supply Bmad's native ring chromaticities; tune
finite differences are saved alongside them as a cross-check.

An RF-off closed ring has no periodic Bmad c mode, so Tao does not return
`phi_c`. The matching coasting `dphi_3/ddelta` is instead calculated from the
central difference of the accumulated longitudinal advance
`orbit_z(s) - orbit_z(beginning)`. The ring slip coefficient is the negative
of this quantity at the end, matching SciBmad's coasting sign convention.

Run on lnx201:

```bash
ssh jn577@lnx201.classe.cornell.edu
cd ~/cesr_scibmad
source ~/venvs/pytao/bin/activate

python dataset_benchmark/optics/benchmark_bmad_optics.py \
  --sample-count=10 \
  --delta-step=1e-5 \
  --output-dir=dataset_benchmark/optics/results/chromatic_test_10
```

Bmad writes:

- `bmad_detector_chromatic_twiss.csv`: the same 990-row, 40-column detector
  schema as SciBmad;
- `bmad_ring_chromatic_twiss.csv`: tunes, native and finite-difference
  chromaticities, slip, and per-sample time;
- `bmad_start_closed_orbits.csv`;
- `bmad_chromatic_optics_metadata.json`;
- the generated RF-off Tao init file.

The Bmad timed region contains the 119-variable update, three Bmad optics
recalculations per sample, and all output queries. Initialization, warmup, and
file writing are excluded and separately recorded. Since SciBmad obtains all
coefficients from one second-order GTPSA map while Bmad uses three energy
points, this benchmark directly measures the value of the higher-order map for
digital-twin dataset generation.

## Shared conventions

- RF is off so `delta` is a fixed momentum offset rather than a synchrotron
  coordinate.
- Closed-orbit closure is evaluated in `(x, px, y, py)`; `z` need not close in
  a coasting ring.
- SciBmad saves values at detector beginnings. Tao returns detector exits;
  because every `DET_*` is a zero-length marker, these are the same location.
- Phases are stored in turns.
- Defaults use the first 10 rows of
  `dataset_benchmark/inputs/cesr_corrector_samples_1000.csv`.
