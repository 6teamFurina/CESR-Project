#!/usr/bin/env julia

"""
Generate exact CESR closed-orbit samples with SciBmad batch parameters.

The timed physics region includes assigning all sampled control arrays, solving
all closed orbits, and tracking the solved orbits to all DET_* markers. Model
loading, Julia compilation warmup, and CSV writing are reported separately.
"""

using Beamlines
using Printf
using SciBmad
using TOML

const HERE = @__DIR__
const PROJECT_ROOT = normpath(joinpath(HERE, ".."))
include(joinpath(PROJECT_ROOT, "cesr_model.jl"))

function parse_args(args)
    options = Dict{String,String}(
        "inputs" => joinpath(HERE, "inputs", "cesr_corrector_samples_1000.csv"),
        "output" => joinpath(HERE, "results", "formal_1000", "scibmad", "scibmad_rf_on_samples.csv"),
        "metadata" => joinpath(HERE, "results", "formal_1000", "scibmad", "scibmad_rf_on_metadata.toml"),
        "mode" => "rf_on",
        "reltol" => "1e-13",
        "abstol" => "1e-13",
        "maxiter" => "100",
        "warmup-samples" => "2",
    )
    for argument in args
        startswith(argument, "--") ||
            error("Arguments must have --name=value form: $argument")
        fields = split(argument[3:end], "="; limit=2)
        length(fields) == 2 || error("Missing value in argument: $argument")
        haskey(options, fields[1]) || error("Unknown option: --$(fields[1])")
        options[fields[1]] = fields[2]
    end
    options["mode"] == "rf_on" ||
        error("The first benchmark release supports --mode=rf_on only")
    return options
end

function read_samples(path::AbstractString)
    lines = readlines(path)
    length(lines) >= 2 || error("Sample CSV has no data: $path")
    header = split(lines[1], ',')
    first(header) == "sample_id" || error("First CSV column must be sample_id")
    names = String.(header[2:end])
    length(names) == 119 || error("Expected 119 controls, found $(length(names))")
    length(unique(names)) == length(names) || error("Control names are not unique")

    sample_ids = Vector{Int}(undef, length(lines) - 1)
    values = Matrix{Float64}(undef, length(lines) - 1, length(names))
    for (row, line) in enumerate(lines[2:end])
        fields = split(line, ',')
        length(fields) == length(header) ||
            error("CSV row $row has $(length(fields)) fields; expected $(length(header))")
        sample_ids[row] = parse(Int, fields[1])
        for column in eachindex(names)
            values[row, column] = parse(Float64, fields[column + 1])
        end
    end
    return (; sample_ids, names, values)
end

detector_names(ring) = [
    uppercase(String(element.name))
    for element in ring.line
    if startswith(uppercase(String(element.name)), "DET_")
]

function prepare_batch_model(
    names::Vector{String},
    values::Matrix{Float64},
)
    n_samples, n_controls = size(values)
    n_controls == length(names) || error("Control matrix width does not match labels")

    model = load_cesr_model(zero_value=BatchParam(0.0), rf_on=true)
    for (column, name) in enumerate(names)
        model.controls[name] = BatchParam(view(values, :, column))
    end
    return model
end

function solve_and_track(
    model,
    n_samples::Int;
    reltol::Float64,
    abstol::Float64,
    maxiter::Int,
)
    detectors = detector_names(model.ring)
    length(detectors) == 99 || error("Expected 99 detectors, found $(length(detectors))")
    solve_seconds = @elapsed begin
        solution = find_closed_orbit(
            model.ring;
            v0=zeros(n_samples, 6),
            coasting_beam=false,
            batch=Val{true}(),
            reltol,
            abstol,
            maxiter,
            warn=false,
        )
    end

    converged = Array(solution.sol.retcode .== SciBmad.BatchSolve.RETCODE_SUCCESS)
    horizontal = similar(solution.v0, n_samples, length(detectors))
    vertical = similar(horizontal)
    track_seconds = @elapsed begin
        bunch = Bunch(v=copy(solution.v0))
        SciBmad.BTBL.check_bl_bunch!(bunch, model.ring, false)
        detector_index = 0
        for element in model.ring.line
            track!(bunch, element)
            name = uppercase(String(element.name))
            startswith(name, "DET_") || continue
            detector_index += 1
            name == detectors[detector_index] ||
                error("Detector order changed at $name")
            horizontal[:, detector_index] .= bunch.coords.v[:, 1]
            vertical[:, detector_index] .= bunch.coords.v[:, 3]
        end
        detector_index == length(detectors) || error("Not all detectors were tracked")
    end

    return (;
        observables=Array(hcat(horizontal, vertical)),
        detectors,
        converged,
        solution,
        solve_seconds,
        track_seconds,
    )
end

function simulate_batch(
    names::Vector{String},
    values::Matrix{Float64};
    reltol::Float64,
    abstol::Float64,
    maxiter::Int,
)
    model_setup_seconds = @elapsed model = prepare_batch_model(names, values)
    result = solve_and_track(model, size(values, 1); reltol, abstol, maxiter)
    return merge(result, (; model_setup_seconds))
end

function write_outputs(path, sample_ids, result)
    mkpath(dirname(path))
    labels = vcat(
        [name * ":x" for name in result.detectors],
        [name * ":y" for name in result.detectors],
    )
    open(path, "w") do io
        println(io, join(vcat("sample_id", "converged", labels), ','))
        for row in eachindex(sample_ids)
            fields = Any[sample_ids[row], result.converged[row]]
            append!(fields, result.observables[row, :])
            println(io, join(fields, ','))
        end
    end
    return labels
end

function main(args=ARGS)
    options = parse_args(args)
    inputs = abspath(options["inputs"])
    output = abspath(options["output"])
    metadata_path = abspath(options["metadata"])
    samples = read_samples(inputs)
    reltol = parse(Float64, options["reltol"])
    abstol = parse(Float64, options["abstol"])
    maxiter = parse(Int, options["maxiter"])
    warmup_samples = min(parse(Int, options["warmup-samples"]), size(samples.values, 1))
    warmup_samples >= 1 || error("--warmup-samples must be positive")

    @printf(
        "SciBmad CESR batch benchmark: %d samples x %d controls\n",
        size(samples.values)...,
    )
    warmup_elapsed = @elapsed simulate_batch(
        samples.names,
        samples.values[1:warmup_samples, :];
        reltol,
        abstol,
        maxiter,
    )
    @printf("Warmup/compilation batch (%d samples): %.3f s\n", warmup_samples, warmup_elapsed)

    model_timed = @timed prepare_batch_model(samples.names, samples.values)
    model = model_timed.value
    timed = @timed solve_and_track(
        model,
        size(samples.values, 1);
        reltol,
        abstol,
        maxiter,
    )
    result = timed.value
    physics_seconds = timed.time
    @printf(
        "Model setup: %.3f s\nPhysics: %.3f s (solve %.3f + track %.3f), %.3f samples/s, converged %d/%d\n",
        model_timed.time,
        physics_seconds,
        result.solve_seconds,
        result.track_seconds,
        size(samples.values, 1) / physics_seconds,
        count(result.converged),
        length(result.converged),
    )

    write_seconds = @elapsed labels = write_outputs(output, samples.sample_ids, result)
    mkpath(dirname(metadata_path))
    metadata = Dict(
        "format" => "cesr-dataset-benchmark-v1",
        "engine" => "SciBmad",
        "device" => "cpu",
        "mode" => options["mode"],
        "input_csv" => inputs,
        "output_csv" => output,
        "sample_count" => size(samples.values, 1),
        "control_count" => size(samples.values, 2),
        "observable_count" => length(labels),
        "detector_count" => length(result.detectors),
        "converged_count" => count(result.converged),
        "failed_count" => count(.!result.converged),
        "warmup_sample_count" => warmup_samples,
        "warmup_seconds" => warmup_elapsed,
        "model_setup_seconds" => model_timed.time,
        "model_setup_allocated_bytes" => model_timed.bytes,
        "physics_seconds" => physics_seconds,
        "closed_orbit_seconds" => result.solve_seconds,
        "detector_tracking_seconds" => result.track_seconds,
        "samples_per_second" => size(samples.values, 1) / physics_seconds,
        "write_seconds" => write_seconds,
        "allocated_bytes" => timed.bytes,
        "gc_seconds" => timed.gctime,
        "julia_version" => string(VERSION),
        "julia_threads" => Threads.nthreads(),
        "reltol" => reltol,
        "abstol" => abstol,
        "maxiter" => maxiter,
        "execution_model" => "one BatchParam array per control; one batched closed-orbit solve",
        "timed_region" => "closed-orbit solve + detector tracking",
    )
    open(metadata_path, "w") do io
        TOML.print(io, metadata; sorted=true)
    end
    println("Output:   $output")
    println("Metadata: $metadata_path")
    return 0
end

exit(main())
