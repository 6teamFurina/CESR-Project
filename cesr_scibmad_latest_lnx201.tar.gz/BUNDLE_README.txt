CESR SciBmad latest lnx201 benchmark bundle

Target:
  /home/jn577/cesr_scibmad

Extract from the lnx201 shell:
  mkdir -p ~/cesr_scibmad
  tar -xzf ~/cesr_scibmad_latest_lnx201.tar.gz -C ~/cesr_scibmad
  cd ~/cesr_scibmad
  bash run_lnx201_latest.sh

The run uses the maintained defaults:
  reltol=1e-8
  abstol=1e-10
  response-linear per-sample initial guesses
  cached 6x119 closed-orbit response
  frozen nominal Jacobian
  mandatory closure validation and full-AD fallback

The archive overwrites only the listed benchmark/model/environment files when
extracted. It does not remove other files from ~/cesr_scibmad.
