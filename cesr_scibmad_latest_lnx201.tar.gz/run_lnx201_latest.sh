#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

if command -v julia >/dev/null 2>&1; then
    JULIA_BIN="$(command -v julia)"
elif [[ -x "$HOME/.juliaup/bin/julia" ]]; then
    JULIA_BIN="$HOME/.juliaup/bin/julia"
else
    echo "Julia was not found in PATH or at $HOME/.juliaup/bin/julia" >&2
    exit 1
fi

export JULIA_PKG_PRECOMPILE_AUTO=0
export JULIA_NUM_THREADS=1

RESULT_DIR="dataset_benchmark/results/formal_1000/scibmad_response_frozen_lnx201"
mkdir -p "$RESULT_DIR"

/usr/bin/time -v "$JULIA_BIN" --project=. \
    dataset_benchmark/benchmark_scibmad.jl \
    --output="$RESULT_DIR/scibmad_rf_on_samples.csv" \
    --metadata="$RESULT_DIR/scibmad_rf_on_metadata.toml" \
    2>&1 | tee "$RESULT_DIR/linux_run.log"

echo
echo "Result directory: $RESULT_DIR"
echo "Confirm that the log contains: Closed-orbit response 6x119: loaded cache"
